const { link } = require("joi");
const { Schema, model } = require("mongoose");

const authorSocialSchema = new Schema(
  {
    author_id: {
      type: Schema.Types.ObjectId,
      ref: "Social",
    },
    social_id: {
      type: Schema.Types.ObjectId,
      ref: "Category",
    },
    social_link: {
        type: String
    }
  },
  {
    versionKey: false,
  }
);
module.exports = model("AuthorSocial", authorSocialSchema);
