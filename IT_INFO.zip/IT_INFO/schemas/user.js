const { date } = require("joi");
const { Schema, model } = require("mongoose");
const userSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true
    },
    phone: {
      type: String,
      required: true,
      unique: true,
    },
    info: {
      type: String,
      trim: true,
    },
    photo: {
      type: String,
      trim: true,
    },
    created_date: {
        type: Date
    },
    updated_date: {
        type: Date
    },
    is_active: {
      type: Boolean,
      default: false,
    },
    activation_link: {
      type: String
    }
  },

  {
    versionKey: false,
  }
);

module.exports = model("User", userSchema);
