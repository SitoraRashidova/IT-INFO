const { boolean } = require("joi");
const {Schema, model} = require("mongoose");

const QA_Schema = new Schema (
    {
        question: {
            type: String,
            trim: true,
            required: true
        },
        answer: {
            type: String,
            trim: true
        },
        created_date: {
            type: Date
        },
        updated_date: {
            type: Date
        },
        is_checked: {
            type: boolean,
            default: false
        },
        user_id: {
            type: Schema.Types.ObjectId,
            ref: "User"
        },
        expert_id: {
            type: Schema.Types.ObjectId,
            ref: "Author"
        }

    },
    {
        versionKey: false
    }
)

module.exports = model("QA", QA_Schema)