const { Schema, model } = require("mongoose");
const adminSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
    phone: {
      type: String,
      required: true,
      trim: true
    },
    created_date: {
      type: Date,
    },
    updated_date: {
      type: Date,
    },
    is_active: {
      type: Boolean,
      default: false,
    },
    is_creator: {
        type: Boolean,
        default: false
    },
    activation_link: {
      type: String
    }
  },
  {
    versionKey: false,
  }
);

module.exports = model("Admin", adminSchema);
