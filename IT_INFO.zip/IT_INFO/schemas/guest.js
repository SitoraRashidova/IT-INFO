const { boolean, string } = require("joi");
const { Schema, model } = require("mongoose");

const guestSchema = new Schema(
  {
    guest_ip: {
      type: String,
      trim: true,
      required: true,
    },
    guest_os: {
      type: String,
      trim: true,
    },
    guest_device: {
      type: String,
    },
    guest_browser: {
      type: String,
    },
    guest_reg_date: {
        type: Date
    }
  },
  {
    versionKey: false,
  }
);

module.exports = model("Guest", guestSchema);
