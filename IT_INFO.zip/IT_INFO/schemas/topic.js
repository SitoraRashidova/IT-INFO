const {Schema, model} = require("mongoose");
const { string, date, boolean } = require("joi");

const topicSchema = new Schema (
    {
        author_id: {
        type: Schema.Types.ObjectId,
        ref: "Author"
        },
        
        title: {
            type: String,
            trim: true,
            maxLength: 256
        },
        text: {
            type: String,
            trim: true
        },
        created_date: {
            type: Date
        },
        updated_date: {
            type: Date,
        },
        is_checked: {
            type: Boolean,
            default: false
        },
        is_approved: {
            type: Boolean,
            default: false
        },
        expert_id: {
            type: Schema.Types.ObjectId,
            ref: "Author"
        }
    },

    {
        versionkey: false
    }
)

module.exports = model("Topic", topicSchema);
   
