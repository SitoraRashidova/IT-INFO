const { Schema, model } = require("mongoose");
const authorSchema = new Schema(
  {
    first_name: {
      type: String,
      required: true,
      trim: true,
    },
    last_name: {
      type: String,
      trim: true
    },
    nick_name: {
      type: String,
      minlength: 5,
      maxlength: 16,
      unique: true
    },
    email: {
      type: String,
      required: true,
      unique: true
    },
    phone: {
      type: String,
      required: true,
      unique: true
    },
    password: {
      type: String,
      required: true
    },
    info: {
      type: String,
      trim: true
    },
    position: {
      type: String,
      trim: true
    },
    photo: {
      type: String,
      trim: true
    },
    is_expert: {
      type: Boolean,
      required: true,
      default: false
    },
    is_active: {
      type: Boolean,
      default: false,
      
    },
    activation_link: {
      type: String
    },
    
    token:{
      type: String,
      
    }
  },

  {
    versionKey: false,
  }
);

module.exports = model("Author", authorSchema);
