const { errorHandler } = require("../helpers/error_handler");
const topic = require("../schemas/topic");
const Joi = require("joi");
const { topicValidation } = require("../validations/topic.validation");

const addTopic = async (req, res) => {
  try {
    const {error, value} = topicValidation(req.body);
      if (error) {
        return res.status(400).send({ message: error.message });
      }
    const { author_id,
        title,
        text,
        created_date,
        updated_date,
        is_checked,
        is_approved,
        expert_id } = value;

    const newTopic = await topic.create({author_id,
        title,
        text,
        created_date,
        updated_date,
        is_checked,
        is_approved,
        expert_id});
    res
      .status(201)
      .send({ message: "New Topic added successfully!", newTopic });
  } catch (error) {
    errorHandler(res, error);
  }
};

const getTopics = async (req, res) => {
  try {
    const Topics = await topic.find();
    res.send(Topics);
  } catch (error) {
    errorHandler(res, error);
  }
};

const updateTopicById = async (req, res) => {
  try {
    const { id } = req.params;
    const { author_id,
        title,
        text,
        created_date,
        updated_date,
        is_checked,
        is_approved,
        expert_id } = req.body;
    const updated_Topic = await topic.findByIdAndUpdate(id, {
      author_id,
        title,
        text,
        created_date,
        updated_date,
        is_checked,
        is_approved,
        expert_id
    });
    if (!updated_Topic) {
      res.status(404).send({ statuscode: 404, message: "Topic not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Topic updated successfully!",
      data: updated_Topic,
    });
  } catch (error) {
    console.log(res, error);
  }
};

const deleteTopicById = async (req, res) => {
  try {
    const { id } = req.params;
    const { author_id,
        title,
        text,
        created_date,
        updated_date,
        is_checked,
        is_approved,
        expert_id } = req.body;
    const deleted_Topic = await topic.findByIdAndDelete(id, {
      author_id,
        title,
        text,
        created_date,
        updated_date,
        is_checked,
        is_approved,
        expert_id,
    });
    if (!deleted_Topic) {
      res.status(404).send({ statuscode: 404, message: "Topic not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Topic deleted successfully!",
      data: deleted_Topic,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};

module.exports = {
  addTopic,
  getTopics,
  updateTopicById,
  deleteTopicById,
};
