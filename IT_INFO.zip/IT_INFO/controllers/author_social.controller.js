const { errorHandler } = require("../helpers/error_handler");
const authorSocial = require("../schemas/author_social");
const Joi = require("joi");
const { authorSocialValidation } = require("../validations/author_social.validation");

const addAuthorSocial = async (req, res) => {
  try {
    const {error, value} = authorSocialValidation(req.body);
      if (error) {
        return res.status(400).send({ message: error.message });
      }
    const { author_id, social_id, social_link  } = value;

    const newAuthorSocial = await authorSocial.create({author_id, social_id, social_link});
    res
      .status(201)
      .send({ message: "New Author Social added successfully!", newAuthorSocial });
  } catch (error) {
    errorHandler(res, error);
  }
};

const getAuthorSocials = async (req, res) => {
  try {
    const Categories = await authorSocial.find();
    res.send(Categories);
  } catch (error) {
    errorHandler(res, error);
  }
};

const updateAuthorSocialById = async (req, res) => {
  try {
    const { id } = req.params;
    const { authorSocial_name } = req.body;
    const updated_AuthorSocial = await authorSocial.findByIdAndUpdate(id, {
      authorSocial_name,
    });
    if (!updated_AuthorSocial) {
      res.status(404).send({ statuscode: 404, message: "AuthorSocial not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "AuthorSocial updated successfully!",
      data: updated_AuthorSocial,
    });
  } catch (error) {
    console.log(res, error);
  }
};

const deleteAuthorSocialById = async (req, res) => {
  try {
    const { id } = req.params;
    const { authorSocial_name } = req.body;
    const deleted_AuthorSocial = await authorSocial.findByIdAndDelete(id, {
      authorSocial_name,
    });
    if (!deleted_AuthorSocial) {
      res.status(404).send({ statuscode: 404, message: "AuthorSocial not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "AuthorSocial deleted successfully!",
      data: deleted_AuthorSocial,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};

module.exports = {
  addAuthorSocial,
  getAuthorSocials,
  updateAuthorSocialById,
  deleteAuthorSocialById,
};
