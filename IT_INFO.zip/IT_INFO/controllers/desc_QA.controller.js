const { errorHandler } = require("../helpers/error_handler");
const descQA = require("../schemas/desc_QA");
const Joi = require("joi");
const { descQAValidation } = require("../validations/desc_QA.validation");

const adddescQA = async (req, res) => {
  try {
    const {error, value} = descQAValidation(req.body);
      if (error) {
        return res.status(400).send({ message: error.message });
      }
    const { qa_id, desc_id} = value;

    const newDescQA = await descQA.create({qa_id, desc_id});
    res
      .status(201)
      .send({ message: "New descQA added successfully!", newDescQA });
  } catch (error) {
    errorHandler(res, error);
  }
};

const getDescQAs = async (req, res) => {
  try {
    const descQAs = await descQA.find();
    res.send(descQAs);
  } catch (error) {
    errorHandler(res, error);
  }
};

const updatedescQAById = async (req, res) => {
  try {
    const { id } = req.params;
    const { qa_id, desc_id } = req.body;
    const updated_descQA = await descQA.findByIdAndUpdate(id, {
      qa_id, desc_id,
    });
    if (!updated_descQA) {
      res.status(404).send({ statuscode: 404, message: "descQA not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "descQA updated successfully!",
      data: updated_descQA,
    });
  } catch (error) {
    console.log(res, error);
  }
};

const deletedescQAById = async (req, res) => {
  try {
    const { id } = req.params;
    const { qa_id, desc_id } = req.body;
    const deleted_descQA = await descQA.findByIdAndDelete(id, {
      qa_id, desc_id,
    });
    if (!deleted_descQA) {
      res.status(404).send({ statuscode: 404, message: "descQA not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "descQA deleted successfully!",
      data: deleted_descQA,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};

module.exports = {
  adddescQA,
  getDescQAs,
  updatedescQAById,
  deletedescQAById,
};
