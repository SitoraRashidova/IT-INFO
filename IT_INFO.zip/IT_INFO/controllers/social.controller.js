const { errorHandler } = require("../helpers/error_handler");
const social = require("../schemas/social");
const Joi = require("joi");
const { socialValidation } = require("../validations/social.validation");

const addSocial = async (req, res) => {
  try {
    const {error, value} = socialValidation(req.body);
      if (error) {
        return res.status(400).send({ message: error.message });
      }
    const { social_name, social_icon_file } = value;

    const newSocial = await social.create({social_name, social_icon_file});
    res
      .status(201)
      .send({ message: "New Social added successfully!", newSocial });
  } catch (error) {
    errorHandler(res, error);
  }
};

const getSocials = async (req, res) => {
  try {
    const Socials = await social.find();
    res.send(Socials);
  } catch (error) {
    errorHandler(res, error);
  }
};

const updateSocialById = async (req, res) => {
  try {
    const { id } = req.params;
    const { social_name, social_icon_file } = req.body;
    const updated_Social = await social.findByIdAndUpdate(id, {
      social_name, social_icon_file
    });
    if (!updated_Social) {
      res.status(404).send({ statuscode: 404, message: "Social not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Social updated successfully!",
      data: updated_Social,
    });
  } catch (error) {
    console.log(res, error);
  }
};

const deleteSocialById = async (req, res) => {
  try {
    const { id } = req.params;
    const { social_name, social_icon_file } = req.body;
    const deleted_Social = await social.findByIdAndDelete(id, {
      social_name, social_icon_file
    });
    if (!deleted_Social) {
      res.status(404).send({ statuscode: 404, message: "Social not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Social deleted successfully!",
      data: deleted_Social,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};

module.exports = {
  addSocial,
  getSocials,
  updateSocialById,
  deleteSocialById,
};
