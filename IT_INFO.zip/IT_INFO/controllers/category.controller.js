const { errorHandler } = require("../helpers/error_handler");
const category = require("../schemas/category");
const Joi = require("joi");
const { categoryValidation } = require("../validations/category.validation");

const addCategory = async (req, res) => {
  try {
    const {error, value} = categoryValidation(req.body);
      if (error) {
        return res.status(400).send({ message: error.message });
      }
    const { category_name, parent_category_id } = value;

    const newCategory = await category.create({category_name});
    res
      .status(201)
      .send({ message: "New Category added successfully!", newCategory });
  } catch (error) {
    errorHandler(res, error);
  }
};

const getCategories = async (req, res) => {
  try {
    const Categories = await category.find();
    res.send(Categories);
  } catch (error) {
    errorHandler(res, error);
  }
};

const updateCategoryById = async (req, res) => {
  try {
    const { id } = req.params;
    const { category_name } = req.body;
    const updated_Category = await category.findByIdAndUpdate(id, {
      category_name,
    });
    if (!updated_Category) {
      res.status(404).send({ statuscode: 404, message: "Category not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Category updated successfully!",
      data: updated_Category,
    });
  } catch (error) {
    console.log(res, error);
  }
};

const deleteCategoryById = async (req, res) => {
  try {
    const { id } = req.params;
    const { category_name } = req.body;
    const deleted_Category = await category.findByIdAndDelete(id, {
      category_name,
    });
    if (!deleted_Category) {
      res.status(404).send({ statuscode: 404, message: "Category not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Category deleted successfully!",
      data: deleted_Category,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};

module.exports = {
  addCategory,
  getCategories,
  updateCategoryById,
  deleteCategoryById,
};
