
const { errorHandler } = require("../helpers/error_handler");
const admin = require("../schemas/admin");
const Admin = require("../schemas/admin");
const { adminValidation } = require("../validations/admin.validation");
const bcrypt = require('bcrypt');
const config = require('config');
const jwt = require('jsonwebtoken');
const myJwt = require("../services/jwt_service");
const { to } = require("../helpers/to_promise");
const uuid = require("uuid");
const mail_service = require("../services/mail.service");

// -------------------------ADD-----------------------------------------------------------
const addAdmin = async (req, res) => {
  try {
    const { error, value } = adminValidation(req.body);
    if (error) {
      return res.status(400).send({ message: error.message });
    }
    console.log(value);
    const {
      name,
      email,
      password,
      phone,
      info,
      photo,
      created_date,
      updated_date,
      is_active,
      is_creator
    } = value;
    const hashedPassword = bcrypt.hashSync(password, 7);
    const activation_link = uuid.v4()

    const newAdmin = await Admin.create({
      name,
      email,
      password: hashedPassword,
      phone,
      info,
      photo,
      created_date,
      updated_date,
      is_active,
      is_creator,
      activation_link
    });

    const payload = {
      _id: newAdmin._id,
      email: newAdmin.email,
      is_expert: newAdmin.is_expert
    }
    const tokens = myJwt.generateTokens(payload);
    newAuthor.token = tokens.refreshToken;
    await newAdmin.save();

    res.cookie("refreshToken", tokens.refreshToken, {
      httpOnly: true,
      maxAge: config.get("refresh_time_ms"),
    })

    res
      .status(201)
      .send({ 
        message: "New Admin added successfully!", 
        id: newAdmin._id,
        accesstoken: tokens.accessToken });
  } catch (error) {
    errorHandler(res, error);
  }
};
// -------------------------------------LOGIN---------------------------------------------------

const loginAdmin = async (req, res) => {
  try {
    const {email, password} = req.body;
    const adminEmail = await Admin.findOne({email})
    if(!adminEmail){
      return res.status(400).send({message: "Email yoki password noto'g'ri!"})
    }
    const valid_Password = bcrypt.compare(password, adminEmail.password)
    if(!valid_Password){
      return res.status(400).send({message: "Email yoki password noto'g'ri!!"})
    } 

    const payload = {
      _id: Admin._id,
      email: Admin.email,
      is_expert: admin.is_expert
    }
  
    const tokens = myJwt.generateTokens(payload);
    Admin.token = tokens.refreshToken;
    await Admin.save();

    res.cookie("refreshToken", tokens.refreshToken, {
      httpOnly: true,
      maxAge: config.get("refresh_time_ms"),
    })
    res.send({message: "User logged in successfully!", id: admin._id, accessToken: tokens.accessToken})
  } catch (error) {
    errorHandler(res, error)
  }
}


// -----------------------------LOGOUT-----------------------------------------

const logoutAdmin = async (req, res) => {
  const {refreshToken} = req.cookies;
  console.log(refreshToken)
  if(!refreshToken){
    return res.status(403).send({error: error.message})
  }
  const author = await Admin.findOneAndUpdate(
    {token: refreshToken},
    {token: ""},
    {new: true}
  )
  if(!author){
    return res.status(400).send({message: "Invalid refresh token"})
  }
  res.clearCookie("refreshToken")
  res.send({refreshToken: admin.token})
}

// --------------------------------refreshToken----------------------------------------------
const refreshToken = async(req, res) => {
  try {
    const {refreshToken} = req.cookies;
  console.log(refreshToken)

  if(!refreshToken){
    return res.status(403).send({message: "Cookieda refresh token topilmadi!"})
  }
  const [error, decodedRefreshToken] = await to(myJwt.verifyRefreshToken(refreshToken))
  if(error){
    return res.status(403).send({error: error.message})
  }
  const adminFromDB = await Admin.findOne({token: refreshToken});
  if(!adminFromDB) {
    return res.status(403).send({message: "Ruxsat etilmagan foydalanuvchi(Refreshtoken mos emas)"})
  }
  const payload = {
    _id: adminFromDB._id,
    email: adminFromDB.email,
    is_expert: adminFromDB.is_creator
  }
  const tokens = myJwt.generateTokens(payload);
  adminFromDB.token = tokens.refreshToken;
  await adminFromDB.save();

  res.cookie("refreshToken", tokens.refreshToken, {
    httpOnly: true,
    maxAge: config.get("refresh_time_ms"),
  })
  res.send({message: "Token refreshshed successfully!", id: adminFromDB._id, accessToken: tokens.accessToken})
  } catch (error) { 
    errorHandler(res, error)
  }
}

// --------------------------------------GET----------------------------------------------------
const getAdmins = async (req, res) => {
  try {
    const authorization = req.headers.authorization;
    if(!authorization){
      return res.status(403).send({message: "Token berilmagan!"})
    }
    console.log(authorization);

    // const bearer = authorization.split(" "[0]);
    // const token = authorization.split(" "[1]);
     const [bearer, token] = authorization.split(" ");
    if(bearer != "Bearer"|| !token){
      return res.status(403).send({message: "Token noto'g'ri!"})
    }
    const tokenKey = config.get("tokenKey");

    const decodedToken = jwt.verify(token, tokenKey )
    console.log("Bu decoded Token:", decodedToken);
    const admins = await Admin.find();
    res.send(admins);
  } catch (error) {
    errorHandler(res, error);
  }
};
// ----------------------------------------UPDATE----------------------------------------------
const updateAdminById = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      name,
      email,
      password,
      phone,
      info,
      photo,
      created_date,
      updated_date,
      is_active,
      is_creator,
      gender,
      birth_date,
      birth_year,
    } = req.body;
    const updated_Admin = await Admin.findByIdAndUpdate(
      id,
      {
        name,
        email,
        password,
        phone,
        info,
        photo,
        created_date,
        updated_date,
        is_active,
        is_creator,
        gender,
        birth_date,
        birth_year,
      },
      { new: true, runValidators: true }
    );
    if (!updated_Admin) {
      res.status(404).send({ statuscode: 404, message: "Admin not found!" });
    }
    return res.status(200).send({
      statuscode: 200,
      message: "Admin updated successfully!",
      data: updated_Admin,
    });
  } catch (error) {
    console.log(res, error);
  }
};
// -----------------------------------------DELETE-------------------------------------------
const deleteAdminById = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted_Admin = await Admin.findByIdAndDelete(id);
    if (!deleted_Admin) {
      res.status(404).send({ statuscode: 404, message: "Admin not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Admin deleted successfully!",
      data: deleted_Admin,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};
// ---------------------------------Activate---------------------
const adminActivate = async (req, res) => {
  try {
    const link = req.params.link
    console.log(link)
    const admin = await Admin.findOne({activation_link: link})
    if(!author){
      return res.status(400).send({message: "Bunday admin topilmadi!"})
    }
    if(author.is_active){
      return res.status(400).send({message: "Bu admin avval faollashtirilgan!"})
    }
    admin.is_active = true
    await admin.save()

    res.send({is_active: admin.is_active, message: "Admin faollashtirildi!"})
  } catch (error) {
    errorHandler(res, error)
  }
}
module.exports = {
  addAdmin,
  getAdmins,
  updateAdminById,
  deleteAdminById,
  loginAdmin,
  logoutAdmin,
  refreshToken,
  adminActivate
};
