const { hashSync } = require("bcrypt");
const { errorHandler } = require("../helpers/error_handler");
const User = require("../schemas/user");
const { userValidation } = require("../validations/user.validation");
const bcrypt = require('bcrypt');
const config = require('config');
const jwt = require('jsonwebtoken');
const user = require("../schemas/user");
const myJwt = require("../services/jwt_service");
const { to } = require("../helpers/to_promise");
const uuid = require("uuid");
const mail_service = require("../services/jwt_service");

const addUser = async (req, res) => {
  try {
    const { error, value } = userValidation(req.body);
    if (error) {
      return res.status(400).send({ message: error.message });
    }
    console.log(value);
    const {
      name,
      email,
      password,
      phone,
      info,
      photo,
      created_date,
      updated_date,
      is_active
    } = value;

    const hashedPassword = bcrypt.hashSync(password, 7);
    const activation_link = uuid.v4()
    const newUser = await User.create({
      name,
      email,
      password: hashedPassword,
      phone,
      info,
      photo,
      created_date,
      updated_date,
      is_active, 
      activation_link
    });

    const payload = {
      _id: newUser._id,
      email: newUser.email,
      is_expert: newUser.is_expert
    }
    const tokens = myJwt.generateTokens(payload);
    newUser.token = tokens.refreshToken;
    await newUser.save();

    res.cookie("refreshToken", tokens.refreshToken, {
      httpOnly: true,
      maxAge: config.get("refresh_time_ms"),
    })

    res
      .status(201)
      .send({ 
        message: "New User added successfully!", 
        id: newUser._id,
        accesstoken: tokens.accessToken });
  } catch (error) {
    errorHandler(res, error);
  }
};
// --------------------------LOGIN-------------------------------------------------------

const loginUser = async (req, res) => {
  try {
    const {email, password} = req.body;
    const userEmail = await User.findOne({email});
    if(!userEmail){
      return res.status(400).send({message: "Email yoki password noto'g'ri!"})
    }
    const validPassword = bcrypt.compare(password, userEmail.password);
    if(!validPassword){
      return res.status(400).send({message: "Email yoki password noto'g'ri!!"})
    }

    const payload = {
      _id: User._id,
      email: User.email,
      is_expert: User.is_expert
    }
  
    const tokens = myJwt.generateTokens(payload);
    User.token = tokens.refreshToken;
    await User.save();

    res.cookie("refreshToken", tokens.refreshToken, {
      httpOnly: true,
      maxAge: config.get("refresh_time_ms"),
    })
    res.send({message: "User logged in successfully!", id: user._id, accessToken: tokens.accessToken})
  } catch (error) {
    errorHandler(res, error);
    console.log
  }
}

// -----------------------------LOGOUT-----------------------------------------

const logoutUser = async (req, res) => {
  const {refreshToken} = req.cookies;
  console.log(refreshToken)
  if(!refreshToken){
    return res.status(403).send({error: error.message})
  }
  const user = await User.findOneAndUpdate(
    {token: refreshToken},
    {token: ""},
    {new: true}
  )
  if(!user){
    return res.status(400).send({message: "Invalid refresh token"})
  }
  res.clearCookie("refreshToken")
  res.send({refreshToken: user.token})
}


// --------------------------------refreshToken----------------------------------------------
const refreshToken = async(req, res) => {
  try {
    const {refreshToken} = req.cookies;
  console.log(refreshToken)

  if(!refreshToken){
    return res.status(403).send({message: "Cookieda refresh token topilmadi!"})
  }
  const [error, decodedRefreshToken] = await to(myJwt.verifyRefreshToken(refreshToken))
  if(error){
    return res.status(403).send({error: error.message})
  }
  const userFromDB = await User.findOne({token: refreshToken});
  if(!userFromDB) {
    return res.status(403).send({message: "Ruxsat etilmagan foydalanuvchi(Refreshtoken mos emas)"})
  }
  const payload = {
    _id: userFromDB._id,
    email: userFromDB.email,
    is_expert: userFromDB.is_active
  }
  const tokens = myJwt.generateTokens(payload);
  userFromDB.token = tokens.refreshToken;
  await userFromDB.save();

  res.cookie("refreshToken", tokens.refreshToken, {
    httpOnly: true,
    maxAge: config.get("refresh_time_ms"),
  })
  res.send({message: "Token refreshshed successfully!", id: userFromDB._id, accessToken: tokens.accessToken})
  } catch (error) { 
    errorHandler(res, error)
  }
}

// ---------------------------------------GET-------------------------------------
const getUsers = async (req, res) => {
  try {
    const authorization = req.headers.authorization;
    if(!authorization){
      return res.status(403).send({message: "Token berilmagan!"})
    }
    const [bearer, token] = authorization.split(" ");
    if(bearer != "Bearer" || !token){
      return res.status(403).send({message: "Token noto'g'ri!"})
    }
    const decodedToken = jwt.verify(token, config.get("tokenKey"));
    console.log("Bu decoded token:", decodedToken)

    const Users = await User.find();
    res.send(Users);
  } catch (error) {
    errorHandler(res, error);
  }
};

const updateUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      name,
      email,
      password,
      phone,
      info,
      photo,
      created_date,
      updated_date,
      is_active,
      gender,
      birth_date,
      birth_year,
    } = req.body;
    const updated_User = await User.findByIdAndUpdate(
      id,
      {
        name,
        email,
        password,
        phone,
        info,
        photo,
        created_date,
        updated_date,
        is_active,
        gender,
        birth_date,
        birth_year,
      },
      { new: true, runValidators: true }
    );
    if (!updated_User) {
      res.status(404).send({ statuscode: 404, message: "User not found!" });
    }
    return res.status(200).send({
      statuscode: 200,
      message: "User updated successfully!",
      data: updated_User,
    });
  } catch (error) {
    console.log(res, error);
  }
};

const deleteUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted_User = await User.findByIdAndDelete(id);
    if (!deleted_User) {
      res.status(404).send({ statuscode: 404, message: "User not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "User deleted successfully!",
      data: deleted_User,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};
// ---------------------------------Activate---------------------
const userActivate = async (req, res) => {
  try {
    const link = req.params.link
    console.log(link)
    const user = await User.findOne({activation_link: link})
    if(!author){
      return res.status(400).send({message: "Bunday user topilmadi!"})
    }
    if(author.is_active){
      return res.status(400).send({message: "Bu user avval faollashtirilgan!"})
    }
    user.is_active = true
    await user.save()

    res.send({is_active: user.is_active, message: "User faollashtirildi!"})
  } catch (error) {
    errorHandler(res, error)
  }
}
module.exports = {
  addUser,
  getUsers,
  updateUserById,
  deleteUserById,
  loginUser,
  logoutUser,
  refreshToken,
  userActivate
};
