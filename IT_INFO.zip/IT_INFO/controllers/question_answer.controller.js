const { errorHandler } = require("../helpers/error_handler");
const QA = require("../schemas/question_answer");
const Joi = require("joi");
const { QAValidation } = require("../validations/question_answer.validation");

const addQA = async (req, res) => {
  try {
    const {error, value} = QAValidation(req.body);
      if (error) {
        return res.status(400).send({ message: error.message });
      }
    const { question, answer, created_date, updated_date, is_checked, user_id, expert_id } = value;

    const newQA = await QA.create({question, answer, created_date, updated_date, is_checked, user_id, expert_id });
    res
      .status(201)
      .send({ message: "New Question-Answer added successfully!", newQA });
  } catch (error) {
    errorHandler(res, error);
  }
};

const getQAs = async (req, res) => {
  try {
    const QAs = await QA.find();
    res.send(QAs);
  } catch (error) {
    errorHandler(res, error);
  }
};

const updateQAById = async (req, res) => {
  try {
    const { id } = req.params;
    const { question, answer, created_date, updated_date, is_checked, user_id, expert_id  } = req.body;
    const updated_QA = await QA.findByIdAndUpdate(id, {
        question, answer, created_date, updated_date, is_checked, user_id, expert_id 
    });
    if (!updated_QA) {
      res.status(404).send({ statuscode: 404, message: "Question-Answer not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Question-Answer updated successfully!",
      data: updated_QA,
    });
  } catch (error) {
    console.log(res, error);
  }
};

const deleteQAById = async (req, res) => {
  try {
    const { id } = req.params;
    const { question, answer, created_date, updated_date, is_checked, user_id, expert_id  } = req.body;
    const deleted_QA = await QA.findByIdAndDelete(id, {
      question, answer, created_date, updated_date, is_checked, user_id, expert_id ,
    });
    if (!deleted_QA) {
      res.status(404).send({ statuscode: 404, message: "Question-Answer not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Question-Answer deleted successfully!",
      data: deleted_QA,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};

module.exports = {
  addQA,
  getQAs,
  updateQAById,
  deleteQAById,
};
