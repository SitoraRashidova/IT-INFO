const { errorHandler } = require("../helpers/error_handler");
const tag = require("../schemas/tag");
const Joi = require("joi");
const { tagValidation } = require("../validations/tag.validation");

const addTag = async (req, res) => {
  try {
    const {error, value} = tagValidation(req.body);
      if (error) {
        return res.status(400).send({ message: error.message });
      }
    const { topic_id, category_id } = value;

    const newTag = await tag.create({topic_id, category_id });
    res
      .status(201)
      .send({ message: "New Tag added successfully!", newTag });
  } catch (error) {
    errorHandler(res, error);
  }
};

const getTags = async (req, res) => {
  try {
    const Tags = await tag.find();
    res.send(Tags);
  } catch (error) {
    errorHandler(res, error);
  }
};

const updateTagById = async (req, res) => {
  try {
    const { id } = req.params;
    const { topic_id, category_id  } = req.body;
    const updated_Tag = await tag.findByIdAndUpdate(id, {
      topic_id, category_id ,
    });
    if (!updated_Tag) {
      res.status(404).send({ statuscode: 404, message: "Tag not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Tag updated successfully!",
      data: updated_Tag,
    });
  } catch (error) {
    console.log(res, error);
  }
};

const deleteTagById = async (req, res) => {
  try {
    const { id } = req.params;
    const { topic_id, category_id  } = req.body;
    const deleted_Tag = await tag.findByIdAndDelete(id, {
      topic_id, category_id ,
    });
    if (!deleted_Tag) {
      res.status(404).send({ statuscode: 404, message: "Tag not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Tag deleted successfully!",
      data: deleted_Tag,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};

module.exports = {
  addTag,
  getTags,
  updateTagById,
  deleteTagById,
};
