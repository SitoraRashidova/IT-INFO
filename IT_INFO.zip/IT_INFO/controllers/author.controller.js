const { errorHandler } = require("../helpers/error_handler");
const author = require("../schemas/author");
const Author = require("../schemas/author");
const { authorValidation } = require("../validations/author.validation");
const bcrypt = require('bcrypt');
const config = require("config");
const myJwt = require("../services/jwt_service");
const { to } = require("../helpers/to_promise");
const uuid = require("uuid");
const mail_service = require("../services/mail.service");

// -------------------------ADD-----------------------------------------------------------
const addAuthor = async (req, res) => {
  try {
    const {error, value} = authorValidation(req.body);
    if (error) {
      return res.status(400).send({ message: error.message });
    }
    console.log(value);
    const {
      first_name,
      last_name,
      nick_name,
      email,
      phone,
      password,
      info,
      position,
      photo,
      is_expert
    } = value;

    const hashedPassword = bcrypt.hashSync(password, 7)
    const activation_link = uuid.v4()

    const newAuthor = await Author.create({
      first_name,
      last_name,
      nick_name,
      email,
      phone,
      password: hashedPassword,
      info,
      position,
      photo,
      is_expert,
      activation_link
    });

    // http://localhost:3000
    await mail_service.sendActivationMail(email, `${config.get("api_url")}:${config.get("port")}/api/author/activate/${activation_link}`)

    const payload = {
      _id: newAuthor._id,
      email: newAuthor.email,
      is_expert: newAuthor.is_expert
    }
  
    const tokens = myJwt.generateTokens(payload);
    newAuthor.token = tokens.refreshToken;
    await newAuthor.save();

    res.cookie("refreshToken", tokens.refreshToken, {
      httpOnly: true,
      maxAge: config.get("refresh_time_ms"),
    })

    res
      .status(201)
      .send({ 
        message: "New Author added successfully!", 
        id: newAuthor._id,
        accesstoken: tokens.accessToken });
  } catch (error) {
    errorHandler(res, error);
  }
};
// -------------------------------------LOGIN---------------------------------------------------
const loginAuthor = async(req, res) => {
  try {
    const {email, password} = req.body
    const Author = await author.findOne({email})
    if(!Author) {
      return res.status(400).send({message: "Email yoki password noto'g'ri!"})
    }
    const validPassword =bcrypt.compareSync(password, Author.password)
    if(!validPassword){
       return res
         .status(400)
         .send({ message: "Email yoki password noto'g'ri!" });
    }
    const payload = {
      _id: Author._id,
      email: Author.email,
      is_expert: Author.is_expert,
      author_roles: ["READ", "WRITE"] //"DELETE"
    }
  
    const tokens = myJwt.generateTokens(payload);
    Author.token = tokens.refreshToken;
    await Author.save();

    res.cookie("refreshToken", tokens.refreshToken, {
      httpOnly: true,
      maxAge: config.get("refresh_time_ms"),
    })
    try {
      setTimeout(function(){
        throw new Error("uncaughtException example")
      });
    } catch (error) {
      console.log(error);
    }

    new Promise((_, reject)=> {
      reject(new Error("unhandledRejection example"))
    })

    res.send({message: "User logged in successfully!", id: author._id, accessToken: tokens.accessToken})
  } catch (error) {
    errorHandler(res, error)
  }
} 


// -----------------------------LOGOUT-----------------------------------------

const logoutAuthor = async (req, res) => {
  const {refreshToken} = req.cookies;
  console.log(refreshToken)
  if(!refreshToken){
    return res.status(403).send({message: "Refresh token topilmadi!"})
  }
  const author = await Author.findOneAndUpdate(
    {token: refreshToken},
    {token: ""},
    {new: true}
  )
  if(!author){
    return res.status(400).send({message: "Invalid refresh token"})
  }
  res.clearCookie("refreshToken")
  res.send({refreshToken: author.token})
}
// --------------------------------refreshToken----------------------------------------------
const refreshToken = async(req, res) => {
  try {
    const {refreshToken} = req.cookies;
  console.log(refreshToken)

  if(!refreshToken){
    return res.status(403).send({message: "Cookieda refresh token topilmadi!"})
  }
  const [error, decodedRefreshToken] = await to(myJwt.verifyRefreshToken(refreshToken))
  if(error){
    return res.status(403).send({error: error.message})
  }
  const authorFromDB = await Author.findOne({token: refreshToken});
  if(!authorFromDB) {
    return res.status(403).send({message: "Ruxsat etilmagan foydalanuvchi(Refreshtoken mos emas)"})
  }
  const payload = {
    _id: authorFromDB._id,
    email: authorFromDB.email,
    is_expert: authorFromDB.is_expert
  }
  const tokens = myJwt.generateTokens(payload);
  authorFromDB.token = tokens.refreshToken;
  await authorFromDB.save();

  res.cookie("refreshToken", tokens.refreshToken, {
    httpOnly: true,
    maxAge: config.get("refresh_time_ms"),
  })
  res.send({message: "Token refreshshed successfully!", id: authorFromDB._id, accessToken: tokens.accessToken})
  } catch (error) { 
    errorHandler(res, error)
  }
}
// ------------------------------------------GET-----------------------------------------------
const getAuthors = async (req, res) => {
  try {
    const id = req.params.id;
    console.log(id);
    console.log(req.author._id);

    if(id !==req.author._id){
      return res.status(403).send({message: "Ruxsat etilmagan foydalanuvchi!"})
    }

    // throw badRequest


    const Authors = await Author.find();
    res.send(Authors);
  } catch (error) {
    // errorHandler(res, error);
  }
};

// ------------------------getById---------------------------------------------------------

const getAuthorById = async (req, res) => {

  try {
    const authorId = req.params.id
    console.log(authorId)
    if (!authorId == req.author._id){
      return res.status(403)
      .send({massage: "Ruxsat etilmagan foydalanuvchi "});
    }
    const { id } = req.params;
    const author = await Author.findById(id);
    if (!author) return res.status(404).send({ message: "Author is not available!" });
    res.send(author);
  } catch (error) {
    errorHandler(res, error);

  }
};
// ----------------------------------------UPDATE----------------------------------------------
const updateAuthorById = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      first_name,
      last_name,
      nick_name,
      email,
      phone,
      password,
      info,
      position,
      photo,
      is_expert,
      is_active,
    } = req.body;
    const updated_Author = await Author.findByIdAndUpdate(
      id,
      {
        first_name,
        last_name,
        nick_name,
        email,
        phone,
        password,
        info,
        position,
        photo,
        is_expert,
        is_active,
      },
      { new: true, runValidators: true }
    );
    if (!updated_Author) {
      res.status(404).send({ statuscode: 404, message: "Author not found!" });
    }
    return res.status(200).send({
      statuscode: 200,
      message: "Author updated successfully!",
      data: updated_Author,
    });
  } catch (error) {
    console.log(res, error);
  }
};
// -----------------------------------------DELETE-----------------------------------------

const deleteAuthorById = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted_Author = await Author.findByIdAndDelete(id);
    if (!deleted_Author) {
      res.status(404).send({ statuscode: 404, message: "Author not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Author deleted successfully!",
      data: deleted_Author,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};

// ---------------------------------Activate---------------------
const authorActivate = async (req, res) => {
  try {
    const link = req.params.link
    console.log(link)
    const author = await Author.findOne({activation_link: link})
    if(!author){
      return res.status(400).send({message: "Bunday avtor topilmadi!"})
    }
    if(author.is_active){
      return res.status(400).send({message: "Bu avtor avval faollashtirilgan!"})
    }
    author.is_active = true
    await author.save()

    res.send({is_active: author.is_active, message: "Avtor faollashtirildi!"})
  } catch (error) {
    errorHandler(res, error)
  }
}
// -----------------------------------------EXPORT---------------------------------------------
module.exports = {
  addAuthor,
  getAuthors,
  updateAuthorById,
  deleteAuthorById, 
  loginAuthor,
  logoutAuthor,
  getAuthorById,
  refreshToken,
  authorActivate
};

