const { errorHandler } = require("../helpers/error_handler");
const descTopic = require("../schemas/desc_topic");
const Joi = require("joi");
const { descTopicValidation } = require("../validations/desc_topic.validation");

const addDescTopic = async (req, res) => {
  try {
    const {error, value} = descTopicValidation(req.body);
      if (error) {
        return res.status(400).send({ message: error.message });
      }
    const { desc_id, topic_id } = value;

    const newDescTopic = await descTopic.create({desc_id, topic_id});
    res
      .status(201)
      .send({ message: "New Description Topic added successfully!", newDescTopic });
  } catch (error) {
    errorHandler(res, error);
  }
};

const getDescTopics = async (req, res) => {
  try {
    const DescTopics = await descTopic.find();
    res.send(DescTopics);
  } catch (error) {
    errorHandler(res, error);
  }
};

const updateDescTopicById = async (req, res) => {
  try {
    const { id } = req.params;
    const { desc_id, topic_id} = req.body;
    const updated_DescTopic = await descTopic.findByIdAndUpdate(id, {
        desc_id, topic_id
    });
    if (!updated_DescTopic) {
      res.status(404).send({ statuscode: 404, message: "Description Topic not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Description Topic updated successfully!",
      data: updated_DescTopic,
    });
  } catch (error) {
    console.log(res, error);
  }
};

const deleteDescTopicById = async (req, res) => {
  try {
    const { id } = req.params;
    const { desc_id, topic_id} = req.body;
    const deleted_DescTopic = await descTopic.findByIdAndDelete(id, {
        desc_id, topic_id
    });
    if (!deleted_DescTopic) {
      res.status(404).send({ statuscode: 404, message: "Desciption Topic not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Description Topic deleted successfully!",
      data: deleted_DescTopic,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};

module.exports = {
  addDescTopic,
  getDescTopics,
  updateDescTopicById,
  deleteDescTopicById,
};
