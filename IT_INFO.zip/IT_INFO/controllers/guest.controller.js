const { errorHandler } = require("../helpers/error_handler");
const guest = require("../schemas/guest");
const Joi = require("joi");
const { guestValidation } = require("../validations/guest.validation");

const addGuest = async (req, res) => {
  try {
    const {error, value} = guestValidation(req.body);
      if (error) {
        return res.status(400).send({ message: error.message });
      }
    const {  guest_ip: 
        type,
      guest_os,
      guest_device,
      guest_browser,
      guest_reg_date } = value;

    const newGuest = await guest.create({ type,
        guest_os,
        guest_device,
        guest_browser,
        guest_reg_date });
    res
      .status(201)
      .send({ message: "New Guest added successfully!", newGuest });
  } catch (error) {
    errorHandler(res, error);
  }
};

const getGuests = async (req, res) => {
  try {
    const Guests = await guest.find();
    res.send(Guests);
  } catch (error) {
    errorHandler(res, error);
  }
};

const updateGuestById = async (req, res) => {
  try {
    const { id } = req.params;
    const {  type,
      guest_os,
      guest_device,
      guest_browser,
      guest_reg_date  } = req.body;
    const updated_Guest = await guest.findByIdAndUpdate(id, {
       type,
      guest_os,
      guest_device,
      guest_browser,
      guest_reg_date ,
    });
    if (!updated_Guest) {
      res.status(404).send({ statuscode: 404, message: "Guest not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Guest updated successfully!",
      data: updated_Guest,
    });
  } catch (error) {
    console.log(res, error);
  }
};

const deleteGuestById = async (req, res) => {
  try {
    const { id } = req.params;
    const {  type,
      guest_os,
      guest_device,
      guest_browser,
      guest_reg_date  } = req.body;
    const deleted_Guest = await guest.findByIdAndDelete(id, {
       type,
      guest_os,
      guest_device,
      guest_browser,
      guest_reg_date ,
    });
    if (!deleted_Guest) {
      res.status(404).send({ statuscode: 404, message: "Guest not found!" });
    }
    res.status(200).send({
      statuscode: 200,
      message: "Guest deleted successfully!",
      data: deleted_Guest,
    });
  } catch (error) {
    errorHandler(res, error);
  }
};

module.exports = {
  addGuest,
  getGuests,
  updateGuestById,
  deleteGuestById,
};
