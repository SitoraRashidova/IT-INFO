async function getAuthors() {
    let accessToken = localStorage.getItem("accessToken");
    let accessTokenExpTime = getTokenExpiration(accessToken);
    console.log("accessTokenExpTime", accessTokenExpTime);

    if (accessTokenExpTime) {
        const currentTime = new Date();
        if (currentTime < accessTokenExpTime) {
            console.log("Access token is active");
        } else {
            console.log("Invalid access token");
            accessToken = await refreshTokenFunc();
            console.log("NewAccessToken:", accessToken);
        }
    } else {
        console.log("Invalid access token format.");
    }

    fetch("http://localhost:3000/api/author", {
        method: "GET",
        headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
        },
        mode: "cors",
    })
        .then((response) => {
            if (response.ok) {
                return response.json();
            } else {
                console.log("Request failed with status: " + response.status);
            }
        })
        .then((author) => {
            console.log(author.data);
            displayAuthors(author.data);
        })
        .catch((error) => {
            console.error("Error: " + error);
        });
}

function getTokenExpiration(token) {
    const decodedToken = JSON.parse(atob(token.split(".")[1]));

    if (decodedToken.exp) {
        return new Date(decodedToken.exp * 1000);
    }
    return null;
}

function displayAuthors(authors) {
    const listContainer = document.getElementById("author-list");

    listContainer.innerHTML = "";

    authors.forEach((author) => {
        const listItem = document.createElement("li");
        listItem.textContent = `${author.first_name} ${author.last_name} - ${author.email}`;
        listContainer.appendChild(listItem);
    });
}

async function refreshTokenFunc() {
    const loginUrl = "/login";
    try {
        const response = await fetch(
            "http://localhost:3000/api/author/refresh",
            {
                method: "POST",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                },
            }
        );
        const data = await response.json();
        
        if (data.error && data.error === "jwt expired") {
            console.log("Refresh token has expired.");
            return window.location.replace(loginUrl);
        }
        console.log("Tokens successfully refreshed using refresh token");
        localStorage.setItem("accessToken", data.accessToken);
        return data.accessToken;
    } catch (error) {
        console.log(error);
        return window.location.replace(loginUrl);
    }
}
