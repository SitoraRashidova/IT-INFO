const express = require("express");
const { addSocial, getSocials, updateSocialById, deleteSocialById } = require("../controllers/social.controller");
const router = express.Router();

router.post("/create", addSocial);
router.get("/", getSocials);
router.patch("/update/:id", updateSocialById);
router.delete("/delete/:id", deleteSocialById);

module.exports = router;