const express = require("express");
const { addCategory, getCategories, updateCategoryById, deleteCategoryById } = require("../controllers/category.controller");
const router = express.Router();

router.post("/create", addCategory);
router.get("/", getCategories);
router.patch("/update/:id", updateCategoryById);
router.delete("/delete/:id", deleteCategoryById);

module.exports = router;