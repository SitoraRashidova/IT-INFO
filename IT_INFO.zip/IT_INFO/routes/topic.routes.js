const express = require('express');
const { addTopic, getTopics, updateTopicById, deleteTopicById } = require('../controllers/topic.controller');
const router = express.Router();

router.post("/create", addTopic);
router.get("/", getTopics);
router.patch("/update/:id", updateTopicById);
router.delete("/delete/:id", deleteTopicById);

module.exports = router;