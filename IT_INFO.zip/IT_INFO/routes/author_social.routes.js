const express = require("express");
const { addAuthorSocial, getAuthorSocials, updateAuthorSocialById, deleteAuthorSocialById } = require("../controllers/author_social.controller");
const router = express.Router();

router.post("/create", addAuthorSocial);
router.get("/", getAuthorSocials);
router.patch("/update/:id", updateAuthorSocialById);
router.delete("/delete/:id", deleteAuthorSocialById);

module.exports = router;