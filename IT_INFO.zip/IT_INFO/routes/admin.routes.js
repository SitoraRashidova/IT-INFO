const express = require("express");
const { addAdmin, getAdmins, updateAdminById, deleteAdminById, loginAdmin, logoutAdmin, refreshToken, adminActivate } = require("../controllers/admin.controller");
const admin_police = require("../middleware/admin._police");
const router = express.Router();
const adminPolice = require("../middleware/admin._police");
const adminRolesPolice = require("../middleware/admin_roles_police")


router.get("/", adminPolice, getAdmins);
router.get("/logout", logoutAdmin);
router.get("/activate/:link", adminActivate)
router.post("/refresh", refreshToken)
router.post("/create", addAdmin);
router.post("/login", loginAdmin);
router.patch("/update/:id", updateAdminById);
router.delete("/delete/:id", deleteAdminById);

module.exports = router;



