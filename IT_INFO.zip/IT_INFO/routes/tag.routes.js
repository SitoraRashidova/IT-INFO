const express = require("express");
const { addTag, getTags, updateTagById, deleteTagById } = require("../controllers/tag.controller");
const router = express.Router();

router.post("/create", addTag);
router.get("/", getTags);
router.patch("/update/:id", updateTagById);
router.delete("/delete/:id", deleteTagById);

module.exports = router;