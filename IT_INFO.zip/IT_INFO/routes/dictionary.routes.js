const express = require("express");
const { addTerm, getTerms, updateTermById, deleteTermById, getTermsByLetter, getTermsByTerm, getTermsByQuery } = require("../controllers/dictionary.controller");
const router = express.Router();

router.post("/create", addTerm);
router.get("/letter/:letter", getTermsByLetter);
router.get("/term/:term", getTermsByTerm);
router.get("/query/search", getTermsByQuery)
router.get("/", getTerms);
router.patch("/update/:id", updateTermById);
router.delete("/delete/:id", deleteTermById);

module.exports = router;
