const express = require("express");
const indexRouter = express.Router();

const dictRouter = require("./dictionary.routes");
const categoryRouter = require("./category.routes");
const descriptionRouter = require("./description.routes");
const synonymRouter = require("./synonym.routes");
const authorRouter = require("./author.routes");
const userRoutes = require("./user.routes");
const adminRoutes = require("./admin.routes");
const socialRoutes = require("../routes/social.routes");
const topicRoutes = require("../routes/topic.routes");
const authorSocialRoutes = require("../routes/author_social.routes");
const descQARoutes = require("../routes/desc_QA.routes");
const descTopicRoutes = require("../routes/desc_topic.routes");
const tagRoutes = require("../routes/tag.routes");


indexRouter.use("/dict", dictRouter);
indexRouter.use("/category", categoryRouter);
indexRouter.use("/desc", descriptionRouter);
indexRouter.use("/syn", synonymRouter);
indexRouter.use("/author", authorRouter);
indexRouter.use("/user", userRoutes);
indexRouter.use("/admin", adminRoutes);
indexRouter.use("/social", socialRoutes);
indexRouter.use("/topic", topicRoutes);
indexRouter.use("/authorSocial", authorSocialRoutes);
indexRouter.use("/descQA", descQARoutes);
indexRouter.use("/descTopic", descTopicRoutes);
indexRouter.use("tag", tagRoutes)



module.exports = indexRouter;
