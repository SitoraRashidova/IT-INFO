const express = require("express");
const { addAuthor, getAuthors, updateAuthorById, deleteAuthorById, loginAuthor, logoutAuthor, getAuthorById, refreshToken, authorActivate } = require("../controllers/author.controller");
const router = express.Router();
const authorPolice = require("../middleware/author_police")
const authorRolesPolice = require("../middleware/author_roles_police")


router.get("/:id",authorRolesPolice(["READ"]), getAuthorById)
router.get("/", authorPolice, getAuthors);
router.get("/logout", logoutAuthor);
router.get("/activate/:link", authorActivate)
router.post("/refresh", refreshToken);
router.post("/create", addAuthor);
router.post("/login", loginAuthor);
router.patch("/update/:id", updateAuthorById);
router.delete("/delete/:id", deleteAuthorById);




module.exports = router;
