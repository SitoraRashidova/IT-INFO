const express = require("express");
const { adddescQA, getDescQAs, updatedescQAById, deletedescQAById } = require("../controllers/desc_QA.controller");
const router = express.Router();

router.post("/create", adddescQA);
router.get("/", getDescQAs);
router.patch("/update/:id", updatedescQAById);
router.delete("/delete/:id", deletedescQAById);

module.exports = router;