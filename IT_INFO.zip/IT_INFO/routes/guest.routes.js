const express = require("express");
const { addGuest, getGuests, updateGuestById, deleteGuestById } = require("../controllers/guest.controller");
const router = express.Router();

router.post("/create", addGuest);
router.get("/", getGuests);
router.patch("/update/:id", updateGuestById);
router.delete("/delete/:id", deleteGuestById);

module.exports = router;