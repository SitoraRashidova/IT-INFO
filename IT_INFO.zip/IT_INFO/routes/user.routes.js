const express = require("express");
const { addUser, getUsers, updateUserById, deleteUserById, loginUser, logoutUser, refreshToken, userActivate } = require("../controllers/user.controller");
const router = express.Router();
const userPolice = require("../middleware/user_police");


router.get("/", userPolice, getUsers);
router.get("/logout", logoutUser);
router.get("/activate/:link", userActivate)
router.post("refresh", refreshToken)
router.post("/create", addUser);
router.post("/login", loginUser);
router.patch("/update/:id", updateUserById);
router.delete("/delete/:id", deleteUserById);

module.exports = router;
