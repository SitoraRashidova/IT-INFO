const express = require("express");
const { addDescTopic, getDescTopics, updateDescTopicById, deleteDescTopicById } = require("../controllers/desc_topic.controller");
const router = express.Router();

router.post("/create", addDescTopic);
router.get("/", getDescTopics);
router.patch("/update/:id", updateDescTopicById);
router.delete("/delete/:id", deleteDescTopicById);

module.exports = router;