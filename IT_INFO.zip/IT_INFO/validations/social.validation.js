const Joi = require("joi");

exports.socialValidation = (data) => {
  const socialSchema = Joi.object({
    social_name: Joi.string().required(),
    social_icon_name: Joi.string()
  });
  return socialSchema.validate(data, { abortEarly: false });
};
