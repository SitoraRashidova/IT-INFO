const Joi = require("joi");

const QA_Validation = (data) => {
    const QA_Schema = Joi.object({
      question: Joi.string().required(),
      answer: Joi.string(),
      created_date: Joi.date(),
      updated_date: Joi.date(),
      is_checked: Joi.boolean(),
      user_id: Joi.string().alphanum().message("ID noto'g'ri"),
      expert_id: Joi.string().alphanum().message("ID noto'g'ri")
    });
    return QA_Schema.validate(data, {abortEarly: false})
}
