const Joi = require("joi"); 

const topicValidation = (data) => {
    const topicSchema = Joi.object({
      author_id: Joi.string(),
      title: Joi.string(),
      text: Joi.string(),
      created_date: Joi.date(),
      updated_date: Joi.date(),
      is_checked: Joi.boolean(),
      is_approved: Joi.boolean(),
      expert_id: Joi.string().alphanum().message("Id noto'g'ri")
    });
    return topicSchema.validate(data, {abortEarly: false})
}

