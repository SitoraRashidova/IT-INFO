const Joi = require("joi");

const guestValidation = (data) => {
  const guestSchema = Joi.object({
    guest_ip: Joi.string(),
    guest_os: Joi.string(),
    guest_device: Joi.string(),
    guest_browser:Joi.string(),
    guest_reg_date: Joi.date()
  });
  return guestSchema.validate(data, { abortEarly: false });
};
