const Joi = require("joi");

exports.userValidation = (data) => {
    const userSchema = Joi.object({
      name: Joi.string(),
      email: Joi.string().email().lowercase(),
      password: Joi.string().pattern(new RegExp("^[a-zA-Z0-9!$#@]{6,30}$")),
      phone: Joi.string().pattern(/^\d{2}-\d{3}-\d{2}-\d{2}$/),
      info: Joi.string(),
      photo: Joi.string().default("user/avatar/png"),
      created_date: Joi.date(),
      updated_date: Joi.date(),
      is_active: Joi.boolean().default(false),
      gender: Joi.string().valid("erkak", "ayol"),
      birth_date: Joi.date().less(new Date("2010-01-01")).greater("2000-01-01"),
      birth_year: Joi.number().integer().min(1980).max(2005),
      referred: Joi.boolean().default(false),
      referredDetails: Joi.string().when("referred", {
        is: true,
        then: Joi.string().required(),
        otherwise: Joi.string().optional()
    })
    });
    return userSchema.validate(data, {abortEarly: false});
}