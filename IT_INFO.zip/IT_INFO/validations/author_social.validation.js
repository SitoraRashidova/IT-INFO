const Joi = require("joi");

const authorSocialValidation = (data) => {
  const authorSocialSchema = Joi.object({
    author_id: Joi.string(),
    social_id: Joi.string(),
    social_link: Joi.string()
  });
  return authorSocialSchema.validate(data, { abortEarly: false });
};
