const Joi = require("joi");

const descTopicValidation = (data) => {
    const descTopicSchema = Joi.object({
    desc_id: Joi.string().alphanum().message("ID noto'g'ri!"),
    topic_id: Joi.string().alphanum().message("ID noto'g'ri!")
});
return descTopicSchema.validate(data, { abortEarly: false });
}
