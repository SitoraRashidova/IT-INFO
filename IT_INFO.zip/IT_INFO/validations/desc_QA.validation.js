const Joi = require('joi');

const descQAValidation = (data) => {
    const descQASchema = Joi.object({
        qa_id: Joi.string().alphanum().message("ID noto'g'ri!"),
        desc_id: Joi.string().alphanum().message("ID noto'g'ri")
    })
    return descQASchema.validate(data, {abortEarly: false})
}

