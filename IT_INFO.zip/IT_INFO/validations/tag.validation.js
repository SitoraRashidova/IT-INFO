const Joi = require('joi');

const tagValidation = (data) => {
    const tagSchema = Joi.object({
        topic_id: Joi.string().alphanum().message("ID noto'g'ri!"),
        category_id: Joi.string().alphanum().message("ID noto'g'ri!")
    })
    return tagSchema.validate(data, {abortEarly: false})
}