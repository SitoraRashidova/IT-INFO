const express = require("express");
const mongoose = require("mongoose");
const config = require("config");
const { errorHandler } = require("./helpers/error_handler");
require("dotenv").config({
  path: `.env.${process.env.NODE_ENV}` //.env.development
})

const logger = require("./services/logger_service");

// console.log(process.env.NODE_ENV);
// console.log(process.env.secret);
// console.log(config.get("secret"));
logger.log("info", "Oddiy Logger");
logger.error("Error Logger");
logger.debug("Debug Logger");
logger.warn("Warn Logger");
logger.info("Info Logger");
// console.trace("Trace Logger");
// console.table([1, 2, 3]);
// console.table([
//   ["Shokir", 22],
//   ["Nodir", 23],
//   ["Qodir", 31]
// ]);

const port = config.get("port");
const mainRouter = require("./routes/index.routes");
const cookieParser = require('cookie-parser');
const winston = require('winston');
const expressWinston = require('express-winston');
const error_handling_middleware = require("./middleware/error_handling_middleware");

// process.on("uncaughtException", (exception) => {
// console.log("uncaughtException", exception)
// // process.exit(1)
// });

// process.on("unhandledRejection", (reject) => {
//   console.log("unhandledRejection", reject);
// })

const app = express();

app.use(express.json());
app.use(cookieParser());
app.use(expressWinstonLogger);
app.use("/api", mainRouter);
app.use(expressWinstonErrorLogger);
app.use(error_handling_middleware) //error handling eng oxirida bo'lishi kerak

async function start() {
  try {
    await mongoose.connect(config.get("dbUri"));
    app.listen(port, () => {
      console.log(`Server started at: ${port}`);
    });
  } catch (error) {
    console.log(error);
  }
}
start();
