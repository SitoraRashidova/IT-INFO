 const express = require("express");
 const mongoose = require("mongoose");
 const config = require("config");
 const cookieParser = require('cookie-parser');
 const winston = require('winston');
 const expressWinston = require("express-winston");
 const exHbs = require("express-handlebars");
 const viewRouter = require("./routes/view.routes");

 require("dotenv").config({
  path: `.env.${process.env.NODE_ENV}` //.env.development
})
const logger = require("./services/logger_service");
const port = config.get("port");
 const mainRouter = require("./routes/index.routes");


 const { errorHandler } = require("./helpers/error_handler");
 const {expressWinstonLogger, expressWinstonErrorLogger} = require("./middleware/express_logger")
 const hbs = exHbs.create({
   defaultLayout: "main",
   extname: "hbs"
 })
 app.use("hsb", hbs.engine)
 app.set("view engine", "hbs")
 app.set("views", "views")
 app.use(express.static("views"));
 const app = express();
 app.use(express.json());
 app.use(cookieParser());
 const error_handling_middleware = require("./middleware/error_handling_middleware");

// app.use(expressWinstonLogger);
app.use("/", viewRouter) //frontend
app.use("/api", mainRouter); //backend
app.use(expressWinstonErrorLogger);

app.use(error_handling_middleware) //error handling eng oxirida bo'lishi kerak

async function start() {
  try {
    await mongoose.connect(config.get("dbUri"));
    app.listen(port, () => {
      console.log(`Server started at: ${port}`);
    });
  } catch (error) {
    console.log(error);
  }
}
start();
