const myJwt = require("../services/jwt_service")
const {to} = require('../helpers/to_promise');

module.exports = function(roles) {
    return async function(req, res, next) {
        try {
            const authorization = req.headers.authorization
            if(!authorization){
              return res.status(403).send({message: "Token berilmagan!"});
            }
            const [bearer, token] = authorization.split(" ");
            if(bearer!="Bearer"|| !token) {
               return res.status(403).send({ message: "Token noto'g'ri!" });
            }
            const [error, decodedToken] = await to(myJwt.verifyAccessToken(token)) ;
            if(error){
                return res.status(403).send({ error: error.message});
            }
            req.user = decodedToken; 
            const{is_active, user_roles} = decodedToken
            let hasRole = false
            user_roles.forEach((user_role) => {
                if(roles.includes(user_role)) hasRole = true
            })
            if(!is_creator || !hasRole) {
                return res.status(401).send({message: "Sizga bunday huquq berilmagan!"})
            }
            console.log(decodedToken);
            
            next()
        } catch (error) {
            console.log(error);
            res.status(403).send({message: "Foydalanuvchi ro'yxatdan o'tmagan!"})
        }
    }
}

